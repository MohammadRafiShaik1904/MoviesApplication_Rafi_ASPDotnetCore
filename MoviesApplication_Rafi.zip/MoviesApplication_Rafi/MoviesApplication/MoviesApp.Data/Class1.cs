﻿using System;

namespace MoviesApp.Data
{
    public class Class1
    {
    }
}
