﻿using System;
using System.Collections.Generic;

namespace MoviesApp.Data.Models
{
    public partial class Movie
    {
        public Movie()
        {
            MovieDetails = new HashSet<MovieDetails>();
        }

        public int MovieId { get; set; }
        public int ProducerId { get; set; }
        public string MovieName { get; set; }
        public int? YearOfRelease { get; set; }
        public string Plot { get; set; }
        public byte[] Poster { get; set; }

        public Producer Producer { get; set; }
        public ICollection<MovieDetails> MovieDetails { get; set; }
    }
}
