﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

namespace MoviesApp.Data.Models
{
    public partial class IMDB_MoviesContext : DbContext
    {
        public IMDB_MoviesContext()
        {
        }

        public IMDB_MoviesContext(DbContextOptions<IMDB_MoviesContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Actor> Actor { get; set; }
        public virtual DbSet<Movie> Movie { get; set; }
        public virtual DbSet<MovieDetails> MovieDetails { get; set; }
        public virtual DbSet<Producer> Producer { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var configuration = new ConfigurationBuilder()
            .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
            .AddJsonFile("appsettings.json")
            .Build();

            optionsBuilder.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Actor>(entity =>
            {
                entity.Property(e => e.ActorName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Bio)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfBirth).HasColumnType("datetime");

                entity.Property(e => e.Sex)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Movie>(entity =>
            {
                entity.Property(e => e.MovieName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Plot)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Poster).HasColumnType("image");

                entity.HasOne(d => d.Producer)
                    .WithMany(p => p.Movie)
                    .HasForeignKey(d => d.ProducerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Movie__ProducerI__3B75D760");
            });

            modelBuilder.Entity<MovieDetails>(entity =>
            {
                entity.HasKey(e => new { e.MovieId, e.ActorId });

                entity.HasOne(d => d.Actor)
                    .WithMany(p => p.MovieDetails)
                    .HasForeignKey(d => d.ActorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__MovieDeta__Actor__3F466844");

                entity.HasOne(d => d.Movie)
                    .WithMany(p => p.MovieDetails)
                    .HasForeignKey(d => d.MovieId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__MovieDeta__Movie__3E52440B");
            });

            modelBuilder.Entity<Producer>(entity =>
            {
                entity.Property(e => e.Bio)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfBirth).HasColumnType("datetime");

                entity.Property(e => e.ProducerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sex)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });
        }
    }
}
