﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MoviesApp.Data.Models
{
   public class MovieViewModel
    {
        public int MovieId { get; set; }
        public int ActorId { get; set; }
        public List<Actor> Actors { get; set; }
        public List<int> SelectedActors { get; set; }
        public Movie Movie { get; set; }

        public MovieViewModel()
        {
            Actors = new List<Actor>();
        }
    }
}
