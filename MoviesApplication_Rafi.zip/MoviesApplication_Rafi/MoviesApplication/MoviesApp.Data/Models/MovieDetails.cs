﻿using System;
using System.Collections.Generic;

namespace MoviesApp.Data.Models
{
    public partial class MovieDetails
    {
        public int MovieId { get; set; }
        public int ActorId { get; set; }
        public double? Investment { get; set; }
        public int? NoOfPrints { get; set; }
        public double? Collections { get; set; }

        public Actor Actor { get; set; }
        public Movie Movie { get; set; }
    }
}
