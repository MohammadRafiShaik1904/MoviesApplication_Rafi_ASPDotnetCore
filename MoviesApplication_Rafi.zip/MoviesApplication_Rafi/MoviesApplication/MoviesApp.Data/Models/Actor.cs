﻿using System;
using System.Collections.Generic;

namespace MoviesApp.Data.Models
{
    public partial class Actor
    {
        public Actor()
        {
            MovieDetails = new HashSet<MovieDetails>();
        }

        public int ActorId { get; set; }
        public string ActorName { get; set; }
        public string Sex { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Bio { get; set; }

        public ICollection<MovieDetails> MovieDetails { get; set; }
    }
}
