﻿using System;
using System.Collections.Generic;

namespace MoviesApp.Data.Models
{
    public partial class Producer
    {
        public Producer()
        {
            Movie = new HashSet<Movie>();
        }

        public int ProducerId { get; set; }
        public string ProducerName { get; set; }
        public string Sex { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Bio { get; set; }

        public ICollection<Movie> Movie { get; set; }
    }
}
