--DB Script for IMDB_Movies
CREATE DATABASE IMDB_Movies
USE IMDB_Movies

IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[dbo].[Producer]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Producer](ProducerId int not null identity(1,1) primary key, ProducerName varchar(50),Sex varchar(10),DateOfBirth DateTime, Bio varchar(100) ) 
END

IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[dbo].[Actor]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Actor](ActorId int not null identity(1,1) primary key, ActorName varchar(50),Sex varchar(10),DateOfBirth DateTime, Bio varchar(100) ) 
END

IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[dbo].[Movie]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Movie](MovieId int not null identity(1,1) primary key,ProducerId int not null, MovieName varchar(50),YearOfRelease int,
Plot varchar(200), Poster image,FOREIGN KEY (ProducerId) REFERENCES Producer(ProducerId) ) 
END

IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[dbo].[MovieDetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MovieDetails](MovieId int not null , ActorId int not null,Investment float,NoOfPrints int,Collections float, primary key (MovieId, ActorId),
FOREIGN KEY (MovieId) REFERENCES Movie(MovieId),FOREIGN KEY (ActorId) REFERENCES Actor(ActorId)  )  
END

BEGIN TRY
    BEGIN TRAN

		INSERT INTO Producer VALUES('Rafi','Male',19-09-1987,'Big Producer')
		INSERT INTO Producer VALUES('Shabna','Female',29-05-1989,'Big Producer')
		
		INSERT INTO Actor VALUES('Chiru','Male',22-08-1949,'He is a versatial actor')
		INSERT INTO Actor VALUES('Kajol','FeMale',22-08-1949,'She is a versatial actor')
		INSERT INTO Actor VALUES('Sharukhan','Male',22-08-1949,'He is a versatial actor')
		INSERT INTO Actor VALUES('Ameer','Male',22-08-1949,'He is a versatial actor')
		INSERT INTO Actor VALUES('Aishwarya','Male',22-08-1949,'She is a versatial actor')
		
		INSERT INTO Movie(ProducerId, MovieName,YearOfRelease,Plot, Poster) 
		SELECT 5,'Dilwale Dulhaniya Lejayenge',1998,'Love Story',BulkColumn 
		from Openrowset (Bulk 'D:\DotNet\MovieSitePOC\Scripts\DdlJposter.jpg', Single_Blob) as Image
		
		INSERT INTO Movie(ProducerId, MovieName,YearOfRelease,Plot, Poster) 
		SELECT 6,'Raja Hindustani',1998,'Love Story',BulkColumn 
		from Openrowset (Bulk 'D:\DotNet\MovieSitePOC\Scripts\raja-hindustani.jpg', Single_Blob) as Image
		
		INSERT INTO Movie(ProducerId, MovieName,YearOfRelease,Plot, Poster) 
		SELECT 5,'Taal',1998,'Love Story',BulkColumn 
		from Openrowset (Bulk 'D:\DotNet\MovieSitePOC\Scripts\Taal.jpg', Single_Blob) as Image
		
		INSERT INTO MovieDetails VALUES(3,2,20000,20,25000)
		INSERT INTO MovieDetails VALUES(3,3,20000,20,25000)
		INSERT INTO MovieDetails VALUES(4,4,20000,20,25000)
		INSERT INTO MovieDetails VALUES(4,2,20000,20,25000)
		INSERT INTO MovieDetails VALUES(5,5,20000,20,25000)

	COMMIT TRAN

END TRY
BEGIN CATCH
    PRINT 'In CATCH Block'
    IF(@@TRANCOUNT > 0)
        ROLLBACK TRAN;

    THROW;
END CATCH

